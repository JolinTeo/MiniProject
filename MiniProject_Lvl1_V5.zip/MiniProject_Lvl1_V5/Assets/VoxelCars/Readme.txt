Open [VoxelCars/Scenes/Demo.scene] to view all cars.
Drag prefabs from [VoxelCars/Prefabs] to add cars to your scene.
Voxel Cars Prototype is very simple models for prototyping your racing game. Made with Unity primitives so you can easy change color and modify them, as well as create your own cars. Please feel free to leave your feedback, rate it and request new features!