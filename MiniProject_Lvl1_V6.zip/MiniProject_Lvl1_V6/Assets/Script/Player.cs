﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    [SerializeField] public TerrainGenerator terrainGenerator;
    [SerializeField] private Text scoreText;
    [SerializeField]
    private int Score;
    private Animator animator;
    private bool isHopping;


    private void Start()
    {
        animator = GetComponent<Animator>();
    }

    private void Update()
    {
        scoreText.text = "Score : " + Score;
        if (Input.GetKeyDown(KeyCode.W) && !isHopping)
        {
            Score += 10;
           
            float xDifference = 0;
            if(transform.position.x % 1 == 0)
            {
                xDifference = Mathf.Round(transform.position.x) - transform.position.x;                
            }
            MoveCharacter(new Vector3(xDifference, 0, 1));
        }
        
        else if(Input.GetKeyDown(KeyCode.A) && !isHopping)
        {

            MoveCharacter(new Vector3(-1, 0, 0));
        }

        else if (Input.GetKeyDown(KeyCode.D) && !isHopping)
        {

            MoveCharacter(new Vector3(1, 0, 0));
        }
    }

    private void MoveCharacter(Vector3 difference)
    {
        animator.SetTrigger("Hop");
        isHopping = true;
        transform.position = (transform.position + difference);
        terrainGenerator.SpawnTerrain(false, transform.position);
    }

    public void FinishHop()
    {
        isHopping = false;
    }

}
